package edu.curso.java.spring.dao;

import edu.curso.java.spring.bo.Cliente;
import java.util.List;

public interface ClienteDAO {
    public long guardarCliente(Cliente cliente);
    public void actualizarCliente(Cliente cliente);
    public void borrarCliente(long id);
    public Cliente buscarClientePorId(long id);
    public List<Cliente> recuperarClientes();
}
