package edu.curso.java.spring.dao;

import edu.curso.java.spring.bo.Cliente;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ClienteDAOImp implements ClienteDAO{

    @Autowired
    private SessionFactory sessionFactory;
    
    @Override
    public long guardarCliente(Cliente cliente) {
        sessionFactory.getCurrentSession().save(cliente);
        return cliente.getId();
    }

    @Override
    public void actualizarCliente(Cliente cliente) {
        sessionFactory.getCurrentSession().update(cliente);
    }

    @Override
    public void borrarCliente(long id) {
        Cliente cliente = this.buscarClientePorId(id);
        sessionFactory.getCurrentSession().delete(cliente);
    }

    @Override
    public Cliente buscarClientePorId(long id) {
        return (Cliente) sessionFactory.getCurrentSession().get(Cliente.class, id);
    }

    @SuppressWarnings("uncheked")
    @Override
    public List<Cliente> recuperarClientes() {
        return sessionFactory.getCurrentSession().createQuery("from Cliente").list();
    }
}