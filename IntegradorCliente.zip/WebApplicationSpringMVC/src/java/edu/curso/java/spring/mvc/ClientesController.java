package edu.curso.java.spring.mvc;

import edu.curso.java.spring.bo.Cliente;
import edu.curso.java.spring.service.ClienteService;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping (value = "/cliente")
public class ClientesController {
    @Autowired
    private ClienteService clienteService;
    
    @RequestMapping(value = "/listar", method = RequestMethod.GET)
    public String listar(Model model) {
        List<Cliente> clientes = clienteService.buscarClientes();
        
        model.addAttribute("clientes", clientes);
        return null;
    }
    
    @RequestMapping(value = "/ver", method = RequestMethod.GET)
    public String ver(Model model, @RequestParam("id")long id) {
        Cliente cliente = clienteService.buscarCliente(id);
        
        model.addAttribute("cliente", cliente);
        return null; //El return null hace que busque un String que machee el con el metodo(en este caso ver)
    }
}
