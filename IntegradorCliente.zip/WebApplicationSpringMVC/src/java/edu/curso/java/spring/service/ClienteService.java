package edu.curso.java.spring.service;

import edu.curso.java.spring.bo.Cliente;
import edu.curso.java.spring.dao.ClienteDAO;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class ClienteService {
    @Autowired
    private ClienteDAO clienteDAO;
    
    public long guardarCliente(Cliente cliente){
        return clienteDAO.guardarCliente(cliente);
    }
    
    public void actualizarCliente(Cliente cliente) {
        clienteDAO.actualizarCliente(cliente);
    }
    
    public void borrarCliente(long id) {
        clienteDAO.borrarCliente(id);
    }
    
    public Cliente buscarCliente(long id) {
        return clienteDAO.buscarClientePorId(id);
    }
    public List<Cliente> buscarClientes() {
        return clienteDAO.recuperarClientes();
    }
}
