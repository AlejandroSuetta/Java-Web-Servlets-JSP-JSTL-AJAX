package edu.curso.java.spring.mvc.form;


import javax.validation.constraints.*;
import org.hibernate.validator.constraints.NotEmpty;


public class clienteForm {
    private long id;
    
    @NotEmpty
    @Size (min = 5, max = 15)
    private String nombre;
    
    @NotEmpty
    @Size (min = 5, max = 15)
    private String apellido;

    public long getId() {return id;}

    public void setId(long id) {this.id = id;}
    public String getNombre() {return nombre;}
    public void setNombre(String nombre) {this.nombre = nombre;}
    public String getApellido() {return apellido;}
    public void setApellido(String apellido) {this.apellido = apellido;}
}
