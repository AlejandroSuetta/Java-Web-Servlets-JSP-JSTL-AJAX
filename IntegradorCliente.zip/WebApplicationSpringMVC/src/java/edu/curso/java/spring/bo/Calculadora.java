/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.curso.java.spring.bo;

/**
 *
 * @author EducaciónIT
 */
public class Calculadora {

    public double sumar(double num1, double num2) {
        return num1 + num2;
    }
    
    public double restar(double num1, double num2) {
        return num1 - num2;
    }
}
