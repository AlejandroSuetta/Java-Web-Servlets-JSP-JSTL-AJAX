package edu.curso.java.servlets;

import java.sql.*;;
import java.util.*;

public class GestorDePersonas {
    public void borrarPersona(Persona persona) {        
        Connection connection = null;
        String url = "jdbc:mysql://127.0.0.1:3306/proyecto_integrador";
        
        String sql = "DELETE FROM persona WHERE id_persona ?";
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(url, "root", ""); //url, usuario, contraseña
            
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, persona.getIdPersona());

            statement.execute();
        }catch(Exception e) {
            System.out.println("Hay un error en el borrar de la personas");
            e.printStackTrace();
        }finally {
            try { connection.close(); }catch(Exception ex) {}
        }
    }
    
    public ArrayList<Persona> buscarPersonas(String textoBuscar) {
        ArrayList<Persona> personas = new ArrayList<>();
        String sql = "SELECT id_persona, nombre, apellido, notas, email, localidad FROM " +
                "persona WHERE nombre like ? or apellido like ?";
        
        String url = "jdbc:mysql://127.0.0.1:3306/proyecto_integrador";
        Connection connection = null;
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(url, "root", ""); //url, usuario, contraseña
            
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, "%" + textoBuscar + "%");
            statement.setString(2, "%" + textoBuscar + "%");
            ResultSet resultado = statement.executeQuery();
            Persona persona = null;
            while(resultado.next()){
                persona = new Persona();
                persona.setIdPersona(resultado.getInt("id_persona"));
                persona.setNombre(resultado.getString("nombre"));
                persona.setApellido(resultado.getString("apellido"));
                persona.setEmail(resultado.getString("email"));
                persona.setLocalidad(resultado.getString("localidad"));
                persona.setNotas(resultado.getString("notas"));
                personas.add(persona);
            }
        }catch(Exception e) {
            System.out.println("Hay un error en el listado de las personas");
            e.printStackTrace();
        }finally {
            try { connection.close(); }catch(Exception ex) {}
        }
        
        return personas;
    }
    
    public void altaPersona(Persona persona){
        Connection connection = null;
        String url = "jdbc:mysql://127.0.0.1:3306/proyecto_integrador";
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(url, "root", ""); //url, usuario, contraseña
            String sql = "INSERT INTO persona (nombre, apellido, email, localidad, notas) " +
                    " VALUES(?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, persona.getNombre());
            statement.setString(2, persona.getApellido());
            statement.setString(3, persona.getNotas());
            statement.setString(4, persona.getEmail());
            statement.setString(5, persona.getLocalidad());
            statement.execute();
        }catch(Exception e) {
            System.out.println("Hay un error en el alta de personas");
            e.printStackTrace();
        }finally {
            try { connection.close(); }catch(Exception ex) {}
        }
    }
}